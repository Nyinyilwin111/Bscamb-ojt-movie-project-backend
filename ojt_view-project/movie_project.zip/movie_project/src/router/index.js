import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import SignInView from '@/views/SignInView.vue'
import RegisterView from '@/views/RegisterView.vue'
import ContactFormView from '@/views/ContactFormView.vue'

const routes = [
    {
    path: '/signin',
    name: 'signin',
    component: SignInView
  },
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
    {
    path: '/register',
    name: 'register',
    component: RegisterView
  },
  {
    path: '/movies',
    name: 'movies',
    component: () => import('@/views/SecondHomeView.vue'),
    meta: { requiresAuth: true },
  },
    {
    path: '/forgetPassword',
    name: 'forgetPassword',
    component: () => import('@/views/ForgetPasswordView.vue'),
    meta: { requiresAuth: true },
  },
    {
    path: '/contact',
    name: 'contact',
    component: ContactFormView
  },
   {
    path: '/movie/detail',
    name: 'detail',
    component: () => import('@/views/DetailView.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/movie/add',
    name: 'addMovie',
    component: () => import('@/views/MovieAddView.vue'),
    meta: { requiresAuth: true },
  },
    {
    path: '/movies/lists',
    name: 'movieLists',
    component: () => import('@/views/GetMovieListView.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/user/lists',
    name: 'userLists',
    component: () => import('@/views/UserListView.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/crew/detail',
    name: 'crewDetail',
    component: () => import('@/views/CrewDetailView.vue'),
    meta: { requiresAuth: true },
  },
  
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
const login = localStorage.getItem("user")
console.log("this is testing",login)

  if (to.meta.requiresAuth) {
    if (login) {
      next()
    } else {
      next('/signin')
    }
  } else {
    
    next()
  }
})

export default router
