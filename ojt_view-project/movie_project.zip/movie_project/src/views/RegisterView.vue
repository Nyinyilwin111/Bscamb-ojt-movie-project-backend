<template>
  <div class="landing-page">
    <div class="overlay"></div>
    <v-container class="d-flex justify-center align-center fill-height">
      <v-card
        class="pa-6"
        max-width="400"
        elevation="10"
        style="background-color: rgba(0, 0, 0, 0.5);"
      >
        <h2 class="text-white mb-6">Register</h2>

        <v-form ref="formRef" @submit.prevent="register">
          <!-- Name -->
          <v-text-field
            v-model="name"
            label="Name"
            class="mb-4"
            color="white"
            density="comfortable"
            bg-color="#1a1a1a"
            :rules="nameRules"
          />

          <!-- Email -->
          <v-text-field
            v-model="email"
            label="Email or mobile number"
            class="mb-4"
            color="white"
            density="comfortable"
            bg-color="#1a1a1a"
            :rules="emailRules"
          />

          <!-- Password -->
          <v-text-field
            v-model="password"
            label="Password"
            class="mb-4"
            :type="showPassword ? 'text' : 'password'"
            density="comfortable"
            bg-color="#1a1a1a"
            color="white"
            :append-inner-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
            @click:append-inner="togglePassword"
          />

          <!-- Confirm Password -->
          <v-text-field
            v-model="confirmPassword"
            label="Confirm Password"
            class="mb-4"
            :type="showConfirmPassword ? 'text' : 'password'"
            density="comfortable"
            bg-color="#1a1a1a"
            color="white"
            :append-inner-icon="showConfirmPassword ? 'mdi-eye' : 'mdi-eye-off'"
            @click:append-inner="toggleConfirmPassword"
            :error="passwordMismatch"
            :error-messages="passwordMismatch ? 'Passwords do not match' : ''"
          />

          <!-- Submit Button -->
          <v-btn block color="red" size="large" class="mb-4" type="submit">
            Register
          </v-btn>

          <div class="text-white text-body-2 mt-6">
            You have a Co-Movie account?
            <a href="/signin" class="text-decoration-underline">Sign In now.</a>
          </div>

          <p class="text-white text-caption mt-2">
            This page is protected by Google reCAPTCHA to ensure you're not a bot.
          </p>
        </v-form>
      </v-card>
    </v-container>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { save } from '@/utils/api.js'
import { useRouter } from 'vue-router'

const router = useRouter()
const formRef = ref(null)
const name = ref('')
const email = ref('')
const password = ref('')
const confirmPassword = ref('')
const showPassword = ref(false)
const showConfirmPassword = ref(false)

const togglePassword = () => showPassword.value = !showPassword.value
const toggleConfirmPassword = () => showConfirmPassword.value = !showConfirmPassword.value

const passwordMismatch = computed(() =>
  confirmPassword.value.length > 0 && password.value !== confirmPassword.value
)

const nameRules = [v => !!v || 'Name is required']
const emailRules = [
  v => !!v || 'Email is required',
  v => /@/.test(v) || 'Email must contain "@"',
  v => /\.com$/.test(v) || 'Email must end with ".com"',
]

const register = async () => {
  const { valid } = await formRef.value.validate();
  if (!valid || passwordMismatch.value) {
    console.error("Form has errors");
    return;
  }

  const formData = new FormData();
  formData.append("name", name.value);
  formData.append("gmail", email.value);
  formData.append("password", password.value);

  try {
    const response = await save("/save", formData);

    if (!response) {
      throw new Error("No response from server");
    }

    // Defensive: only parse JSON if Content-Type is JSON
    const contentType = response.headers.get("content-type");
    let result = null;
    if (contentType && contentType.includes("application/json")) {
      result = await response.json();
    } else {
      // Fallback: maybe text or empty response
      const text = await response.text();
      console.warn("Non-JSON response:", text);
      throw new Error("Server did not return JSON");
    }

    if (response.ok && (response.status === 200 || response.status === 201)) {
      console.log("User saved successfully:", result);

      // Clear form
      name.value = '';
      email.value = '';
      password.value = '';
      confirmPassword.value = '';
      await formRef.value.resetValidation();

      alert("Registration successful! You can now sign in.");
      router.push('/signin');

    } else {
      console.error("Backend returned error:", result);
      alert("Registration failed. Please check your inputs.");
    }
  } catch (err) {
    console.error("Network or server error:", err);
    alert("An error occurred during registration.");
  }
};

</script>

<style scoped>
.text-white input {
  color: white !important;
}
.mb-6{
   font-family: "Fjalla One", sans-serif;
}
.v-input__control {
  border-radius: 4px !important;
}
.landing-page {
  background-image: url('@/assets/background.jpg');
  background-size: cover;
  background-position: center;
  min-height: 100vh;
  padding: 2rem;
  overflow: hidden;
}
.overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 0;
}
/* password and email */

.mb-4,
.custom-password-input label {
  color: #aaa;
}   
.mb-4,
.custom-password-input .v-field__field {
  background-color: #1a1a1a;
}
.small-icon .v-icon {
  font-size: 9px !important; 
}
.error-border input {
  border: 1px solid red !important;
}
</style>
