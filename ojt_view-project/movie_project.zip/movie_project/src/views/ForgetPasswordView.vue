<template>
  <div class="forgot-page">
    <div class="overlay"></div>
    <v-container class="d-flex justify-center align-center fill-height">
      <v-card class="pa-6 reset-card" max-width="500" elevation="12">
        <h2 class="text-h5 font-weight-bold mb-4">Update password, email or phone</h2>

        <p class="mb-2">How would you like to reset your password?</p>
        <v-radio-group v-model="method" class="mb-4">
          <v-radio label="Email" value="email" />
          <v-radio label="Text Message (SMS)" value="sms" />
        </v-radio-group>

        <p class="mb-2" v-if="method === 'sms'">
          We will text you a verification code to reset your password. Message and data rates may apply.
        </p>
        <p class="mb-2" v-if="method === 'email'">
         We will send you an email with instructions on how to reset your password.
        </p>

        <v-text-field
          v-model="inputValue"
          :label="method === 'email' ? 'Email address' : 'Mobile number'"
          :placeholder="method === 'email' ? 'Enter your email' : 'Enter your mobile number'"
          :type="method === 'email' ? 'email' : 'tel'"
          variant="outlined"
          density="comfortable"
          class="mb-4"
        />

        <v-btn color="red" size="large" block @click="handleSubmit">
          {{ method === 'email' ? 'Email Me' : 'Text Me' }}
        </v-btn>
      </v-card>
    </v-container>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const method = ref('sms')
const inputValue = ref('')

const handleSubmit = () => {
  if (method.value === 'sms') {
    console.log('Texting verification to:', inputValue.value)
    // send SMS logic
  } else {
    console.log('Sending reset link to:', inputValue.value)
    // send email logic
  }
}
</script>

<style scoped>
.forgot-page {
  background: url('@/assets/background.jpg') center/cover no-repeat;
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.8);
  z-index: 0;
}

.reset-card {
  background-color: white;
  z-index: 1;
  margin-top: 50px;
}
</style>
