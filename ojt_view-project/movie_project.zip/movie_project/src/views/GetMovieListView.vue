<template>
  <v-card flat>
    <v-card-title class="d-flex align-center pe-2">
      <v-icon icon="mdi-video-input-component"></v-icon> &nbsp;
      Movies List

      <v-spacer></v-spacer>

      <v-text-field
        v-model="search"
        density="compact"
        label="Search"
        prepend-inner-icon="mdi-magnify"
        variant="solo-filled"
        flat
        hide-details
        single-line
      ></v-text-field>
    </v-card-title>

    <v-divider></v-divider>

    <v-data-table
      v-model:search="search"
      :items="movies"
      :headers="headers"
      class="elevation-1"
    >

      <!-- eslint-disable-next-line vue/valid-v-slot -->
      <template #item.movie_poster="{ item }">
        <v-img
          :src="fixImagePath(item.movie_poster)"
          alt="Movie Poster"
          width="200"
          height="80"
          class="rounded-lg"
          cover
        />
      </template>

      <!-- eslint-disable-next-line vue/valid-v-slot -->
      <template #item.likes="{ item }">
        <div class="d-flex align-center">
          <v-icon color="red">mdi-heart</v-icon>
          <span class="ms-1">{{ item.likes }}</span>
        </div>
      </template>

      <!-- eslint-disable-next-line vue/valid-v-slot -->
      <template #item.movie_created_date="{ item }">
        {{ formatDate(item.movie_created_date) }}
      </template>

      <!-- eslint-disable-next-line vue/valid-v-slot -->
      <template #item.actions="{ item }">
        <v-btn icon color="red" @click="deleteMovie(item)">
          <v-icon>mdi-delete</v-icon>
        </v-btn>
      </template>
    </v-data-table>
  </v-card>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { get_AllMovies, delete_Movie } from '@/utils/api.js'

const search = ref('')
const movies = ref([])

const headers = [
  { title: 'Movie Name', key: 'name' },
  { title: 'Movie Image', key: 'movie_poster' },
  { title: 'Likes', key: 'likes', align: 'center' },
  { title: 'Created Date', key: 'movie_created_date' },
  { title: 'Actions', key: 'actions', sortable: false },
]

// Fetch movies
onMounted(async () => {
  try {
    const res = await get_AllMovies('/getAll')
    const data = await res.json()
    movies.value = data
  } catch (err) {
    console.error('Failed to load movies', err)
  }
})

// Delete movie
const deleteMovie = async (movie) => {
  const confirmDelete = confirm(`Are you sure you want to delete "${movie.name}"?`)
  if (!confirmDelete) return

  try {
    const res = await delete_Movie(`/delete/${movie.id}`)
    console.log('movie id is :',movie.id)
    if (res.ok) {
      movies.value = movies.value.filter(m => m.id !== movie.id)
    } else {
      console.error('Delete failed')
    }
  } catch (err) {
    console.error('Failed to delete movie', err)
  }
}

// Image path fixer
const fixImagePath = (path) => {
  if (!path) return ''

 return `http://localhost:8082/storage${path}`
}

// Date formatter from timestamp
const formatDate = (timestamp) => {
  if (!timestamp) return ''
  const date = new Date(Number(timestamp))
  return date.toISOString().split('T')[0] // "YYYY-MM-DD"
}
</script>
