<template>
  <div
    class="back"
    :style="{ backgroundImage: `url(${downImage})` }"
  >
    <v-container>
      <v-row>
        <v-col cols="12" md="6" class="left">
          <h1 class="header">{{ categoryTitle }}</h1>
        </v-col>
        <v-col cols="12" md="6" />
      </v-row>
      <v-row>
        <v-col>
          <p class="paragraph" v-html="textParagraph"></p>
        </v-col>
      </v-row>
    </v-container>
      <div class="overlay"></div>
  </div>

  <br /><br /><br />

  <!-- Movies Section -->
  <div class="second-container">
    <v-container fluid>
      <v-row>
        <v-col cols="12" v-if="movies.length === 0">
          <p class="text-center" style="color: aliceblue;">No movies found in this category.!</p>
        </v-col>
        <v-col v-for="(movie, index) in movies" :key="index" cols="12" sm="6" md="4" lg="2">
          <v-img
            :src="movie.image"
            :alt="movie.title"
            cover
            class="responsive-image"
            style="cursor: pointer;"
            @click="nextPage(movie)"
          />
          <p class="movie-name">{{ movie.title }}</p>
          <p class="year">{{ movie.year }}</p>
        </v-col>

      </v-row>
    </v-container>

    <!-- Plex Section -->
    <v-container class="plex-container" fluid>
      <v-row align="center" justify="center" class="text-center">
        <v-col cols="12">
          <p class="first">Take Plex everywhere</p>
          <p class="second">Watch free anytime, anywhere, on almost any device.</p>
        </v-col>
        <v-col cols="12" md="8">
          <v-img
            :src="require('@/assets/device.png')"
            alt="Devices"
            class="device-image"
            width="100%"
            contain
          />
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script setup>
import { computed, watch, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import api from '@/utils/api.js'
const store = useStore()
const router = useRouter()
const movielist = ref([])
const BASE_URL = 'http://localhost:8082/storage'
const category = computed(() => store.getters.GET_CATEGORY)

// get movies based on category
const get_AllMovies = async (categoryId) => {
  try {
    const res = await api.getMovieswithCategory(`/category/${categoryId}`)
    const data2 = await res.json()
    movielist.value = data2
    console.log('Movies fetched for category:', movielist.value)
    store.commit('SET_MOVIE', data2)
  } catch (err) {
    console.error('Failed to fetch movies:', err)
  }
}

async function getAllCategory() {
  try {
    const res = await api.get_AllCategory('/getAllCategory')
    const data = await res.json()

    console.log('Selected category from store:', category.value)
    console.log('All categories from backend:', data.map(c => c.categoryName))

    const matched = data.find(
      c => c.categoryName.toLowerCase() === category.value.toLowerCase()
    )

    if (matched) {
      console.log('Matched category ID:', matched.c_id)
      await get_AllMovies(matched.c_id)
      return matched.c_id
    } else {
      console.warn('No matching category found.')
      return null
    }
  } catch (err) {
    console.error('Failed to load categories:', err)
  }
}

watch(category, async (newVal) => {
  if (!newVal) return
  console.log('Updated category:', newVal)
  await getAllCategory()
}, { immediate: true })

const nextPage = (name) => {
  console.log('Navigating to detail page for movie in second home view:', name)
  store.dispatch('addMovie', name)
  router.push('/movie/detail')
}

const categoryTitle = computed(() => {
  switch (category.value) {
    case 'Action': return 'Action Movies & TV Shows'
    case 'Drama': return 'Drama Movies & TV Shows'
    case 'Animation': return 'Animation Movies & TV Shows'
    case 'Crime': return 'Crime Movies & TV Shows'
    default: return 'Crime Movies & TV Shows'
  }
})

const textParagraph = computed(() => {
  switch (category.value) {
    case 'Action':
      return 'Welcome to the edge of your seat, because it is time to dive into the <br> action. From classic westerns and war films to modern action hero <br> adventures, it is all right here on Plex.'
    case 'Drama':
      return 'Dramatic movies often defy classification. If it is not funny or scary <br> then it may be a drama. While there will always be crossovers, Plex <br> has put together the best dramatic movies and shows we could find <br> for you to enjoy.'
    case 'Animation':
      return 'From the earliest hand-drawn cartoons to the blockbuster <br> computer-driven events of today, the animated movies and shows <br> you want to watch are right here.'
    case 'Crime':
      return 'Corruption and greed fuel the action of the very best crime movies <br> and shows. Watch devious masterminds try and take over the city <br> while the cops work tirelessly to stop them.'
    default:
      return 'Corruption and greed fuel the action of the very best crime movies <br> and shows. Watch devious masterminds try and take over the city <br> while the cops work tirelessly to stop them.'
  }
})

const downImage = computed(() => {
  switch (category.value) {
    case 'Action': return require('@/assets/ooip.jpg')
    case 'Crime': return require('@/assets/crimeback.jpg')
    case 'Animation': return require('@/assets/animae.jpg')
    case 'Drama': return require('@/assets/drama.jpg')
    default: return require('@/assets/background.jpg')
  }
})
 
const movies = computed(() => {
  return movielist.value.map(movie => ({
    title: movie.name,
    image: movie.movie_poster ? `${BASE_URL}${movie.movie_poster}` : downImage.value,
    year: new Date(movie.movie_created_date).getFullYear(),
    trailer: movie.trailer ? `${BASE_URL}${movie.trailer}` : '',
    fullMovie: movie.movies ? `${BASE_URL}${movie.movies}` : '',
    description: movie.discuss || '',
    crew: movie.crew || [],
    createdDate: movie.movie_created_date,
    movie_id: movie.id ? movie.id : null,
  }))
})

</script>


<style scoped>
.back {
  position: relative;
  width: 100%;
  height: 97vh;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  display: flex;
  align-items: center;
}
.back .v-container {
  position: relative;
  z-index: 2;
}
.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7); 
  z-index: 1;
}
.left {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}
.header {
  color: white;
  font-size: 3rem;
  font-weight: bold;
  margin-top: 1rem;
}
.paragraph {
  color: white;
  font-size: 1.2rem;
  font-weight: bold;
  margin-right: 2rem;
}
.second-container {
  background-color: rgba(0, 0, 0, 0.9);
  padding: 2rem;
  margin-top: -6rem;
}
.responsive-image {
  border-radius: 8px;
  width: 97%;
  height: 20rem;
  transition: transform 0.3s ease;
}
.responsive-image:hover {
  transform: scale(1.05);
}
.movie-name {
  color: white;
  font-size: 1.3rem;
  margin-top: 1rem;
}
.year {
  color: rgb(81, 81, 81);
  font-size: 0.8rem;
  font-weight: 800;
}
.plex-container {
  padding: 3rem 1rem;
  background-color: rgba(0, 0, 0, 0);
  color: white;
}
.first {
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
}
.second {
  font-size: 1.2rem;
  color: #bbbbbb;
  margin-bottom: 2rem;
}
.device-image {
  max-width: 100%;
  border-radius: 10px;
  margin-left: 60px;
}

</style>
