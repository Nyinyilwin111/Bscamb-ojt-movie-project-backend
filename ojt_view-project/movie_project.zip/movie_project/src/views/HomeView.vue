<template>
  <div class="landing-page">
    <div class="overlay"></div>
    <div class="hero">
      <h1 class="title">Unlimited movies, <br>TV shows, and more</h1>
      <p class="subtitle">Starts at USD 2.99. Cancel anytime.</p>
      <p class="email-prompt">
        Ready to watch? Enter your email to create or restart your membership.
      </p>

      <form class="email-form" @submit.prevent="validateAndRegister">
        <input type="email" v-model="email" placeholder="Email address" class="email-input" />
        <button type="submit" class="get-started">Get Started</button>
    </form>

    </div>
    <svg class="bottom-curve" viewBox="0 0 1440 150" preserveAspectRatio="none">
      <path d="M0,150 C480,50 960,50 1440,150" stroke="#ff0050" stroke-width="3" />
    </svg>
  </div>
  <div style="background-color: black;">
    <v-container>
       <h2 style="color: aliceblue;">Trending Now</h2>
      <v-sheet class="mx-auto" elevation="8" max-width="100%">
        <v-slide-group v-model="model" class="pa-4" selected-class="bg-primary" show-arrows>
          <template #prev>
            <v-btn icon color="white">
              <v-icon>mdi-chevron-left</v-icon>
            </v-btn>
          </template>
          <template #next>
            <v-btn icon color="white">
              <v-icon>mdi-chevron-right</v-icon>
            </v-btn>
          </template>

          <v-slide-group-item
            v-for="(movie, index) in formattedMovies"
            :key="movie.movie_id"
            v-slot="{ isSelected, toggle, selectedClass }"
          >
            <v-card
              :class="['ma-4', 'position-relative', selectedClass]"
              color="grey-lighten-1"
              height="250"
              width="200"
              @click="toggle"
            >
              <v-img
                :src="fixImagePath(movie.image)"
                alt="Movie Poster"
                height="100%"
                width="100%"
                class="rounded-lg"
                cover
                @click="nextPage(movie)"
              />
              <div class="d-flex fill-height align-center justify-center">
                <v-scale-transition>
                  <v-icon v-if="isSelected" color="white" icon="mdi-close-circle-outline" size="48" />
                </v-scale-transition>
              </div>
              <div class="movie-number">{{ index + 1 }}</div>
            </v-card>
          </v-slide-group-item>
        </v-slide-group>

        <v-expand-transition>
          <v-sheet v-if="model != null" height="400">
            <div class="d-flex fill-height align-center justify-center">
              <h3 class="text-h6">
                Selected {{ model }}
              </h3>

            </div>
          </v-sheet>
        </v-expand-transition>
      </v-sheet>
    </v-container> 
    
    <v-container>
      <h2 style="color: aliceblue;">More Reasons to Join</h2> <br>
      <v-row>
        <!-- card1 -->
        <v-col cols="12" md="3">
          <v-card class="card" elevation="6">
            <v-card-title class="text-white" style="font-size: 23px">Enjoy on your TV</v-card-title>
            <v-card-text class="text-white">
              Watch on Smart TVs, Playstation, Xbox, Chromecast, Apple TV, Blu-ray players, and more.
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-img src="@/assets/tv.png" alt="TV" width="50" height="50" contain class="mt-4" ></v-img>
            </v-card-actions>
          </v-card>
        </v-col>
        <!-- card2 -->
         <v-col cols="12" md="3">
          <v-card class="card" elevation="6">
            <v-card-item>
              <v-card-title style="font-size: 23px">Download your shows <br> to watch offline</v-card-title>
            </v-card-item>

            <v-card-text>
              Save your favorites easily and always have something to watch.
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-img src="@/assets/down.png" alt="TV" width="50" height="50" contain class="mt-4" ></v-img>
            </v-card-actions>
          </v-card>
        </v-col>
        <!-- card3 -->
         <v-col cols="12" md="3">
          <v-card class="card" elevation="6">
            <v-card-item>
              <v-card-title style="font-size: 23px">Watch everywhere</v-card-title>
            </v-card-item>

            <v-card-text>
              Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV.
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-img src="@/assets/micro.png" alt="TV" width="50" height="50" contain class="mt-4" ></v-img>
            </v-card-actions>
          </v-card>
        </v-col>
        <!-- card4 -->
         <v-col cols="12" md="3">
          <v-card class="card" elevation="6">
            <v-card-item>
              <v-card-title style="font-size: 23px">Create profiles for kids</v-card-title>
            </v-card-item>

            <v-card-text>
              Send kids on adventures with their favorite characters in a space made just for them — free with your membership.
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-img src="@/assets/message.png" alt="TV" width="50" height="50" contain class="mt-4" ></v-img>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container> 

    <v-container>
    <h2 class="faq-title">Frequently Asked Questions</h2>
    <v-row>
      <v-col cols="12">
        <v-expansion-panels multiple variant="inset" class="my-4">
          <v-expansion-panel
            v-for="(faq, index) in faqs"
            :key="index"
          >
            <v-expansion-panel-title style="font-size: 20px;">{{ faq.title }}</v-expansion-panel-title>
            <v-expansion-panel-text>{{ faq.text }}</v-expansion-panel-text>
          </v-expansion-panel>
        </v-expansion-panels>
      </v-col>
    </v-row>
  </v-container>
  </div>
  
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/utils/api.js'
import { useStore } from 'vuex'

const store = useStore()
const email = ref('')
const router = useRouter()
const movieTrend = ref([])
const movies = ref([])
const BASE_URL = 'http://localhost:8082/storage'
const faqs = [
  {
    title: "What is Co-Movie?",
    text: `Co-Movie is a streaming service that offers a wide variety of award-winning TV shows, movies, anime, documentaries,
    and more on thousands of internet-connected devices. You can watch as much as you want, whenever you want without a single
    commercial – all for one low monthly price. There's always something new to discover and new TV shows and movies are added every week!`,
  },
  {
    title: "How much does Co-Movie cost?",
    text: `Watch Co-Movie on your smartphone, tablet, Smart TV, laptop, or streaming device, all for one fixed monthly fee.
    Plans range from USD 2.99 to USD 9.99 a month. No extra costs, no contracts.`,
  },
  {
    title: "Where can I watch Co-Movie?",
    text: `Watch instantly from any internet-connected device that supports Co-Movie, including Smart TVs, game consoles,
    streaming media players, set-top boxes, smartphones, and tablets. You can also stream on your laptop or desktop computer.`,
  },
  {
    title: "How do I cancel my Co-Movie subscription?",
    text: `You can cancel your Co-Movie subscription at any time. There are no cancellation fees – start or stop your account at any time.`,
  },
  {
    title: "What can I watch on Co-Movie?",
    text: `Co-Movie offers a wide variety of award-winning TV shows, movies, anime, documentaries, and more on thousands of internet-connected devices.
    You can watch as much as you want, whenever you want without a single commercial – all.`,
  },
  {
    title: "Is Co-Movie suitable for kids?",
    text: `Yes! Co-Movie has a dedicated Kids section that is full of titles that are age-appropriate for children.
    You can also create a Kids profile that will restrict the content to only those titles that are suitable for children.
    This profile will also have a kid-friendly interface and will not show any content that is not suitable for kids.`,
  },
];

const fetchTrendingMovies = async () => {
  try {
    const response = await api.trendMovie('/topLiked')
    const data = await response.json()
    console.log('Raw trending response:', data)

    if (!Array.isArray(data)) {
      console.error('Trending movies response is not an array:', data)
      return
    }

    const seenIds = new Set()
    const uniqueTrendMovies = data.filter(item => {
      if (!item.movieId || seenIds.has(item.movieId)) return false
      seenIds.add(item.movieId)
      return true
    })

    console.log('Unique movie IDs:', uniqueTrendMovies.map(m => m.movieId))

    const movieData = await Promise.all(
      uniqueTrendMovies.map(async item => {
        const res = await api.get_AllMovies(`/getMovie/withId/${item.movieId}`)
        if (!res.ok) throw new Error(`Failed to fetch movieId: ${item.movieId}`)
        const movie = await res.json()
        return {
          ...movie,
          movieId: item.movieId, // fallback to trend movie ID
        }
      })
    )

    movieTrend.value = uniqueTrendMovies
    movies.value = movieData

    console.log('Fetched movie details:', movieData)

  } catch (error) {
    console.error('Error fetching trending movies:', error)
  }
}

onMounted(() => {
  fetchTrendingMovies()
})

function validateAndRegister() {
  if (!email.value || !isValidEmail(email.value)) {
    alert("Please enter a valid email address.")
    return
  }
  router.push('/register')
}

function isValidEmail(value) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(value) && value.endsWith('.com')
}

const fixImagePath = (path) => {
  if (!path) return ''
  return path.startsWith('http') ? path : `${BASE_URL}${path}`
}

const formattedMovies = computed(() => {
  return movies.value.map(movie => ({
    title: movie.name || 'Unknown Movie',
    image: fixImagePath(movie.movie_poster),
    year: movie.movie_created_date ? new Date(movie.movie_created_date).getFullYear() : '',
    trailer: fixImagePath(movie.trailer),
    fullMovie: fixImagePath(movie.movies),
    description: movie.discuss || '',
    crew: movie.crew || [],
    createdDate: movie.movie_created_date || '',
    movie_id: movie.movieId || movie.id || null, // ✅ key fix here
  }))
})

const nextPage = (movie) => {
  if (!movie.movie_id || typeof movie.movie_id !== 'number') {
    console.warn('Invalid movie selected. Missing or invalid movie_id:', movie)
    return
  }
  console.log('Navigating to detail page for movie:', movie)
  store.dispatch('addMovie', movie)
  router.push('/movie/detail')
}

</script>
<style scoped>
.card{
  background: linear-gradient(135deg, #0f0f2d, #170110);
  color: white;
  height: 6cm;
}
.my-4 {
  background: none;
}
.expanded-panel {
  background-color: #b91c1c !important; /* Dark grey when expanded */
  transition: background-color 0.3s ease;
  border-radius: 10px;
}
.faq-title {
  color: aliceblue;
  font-size: 28px;
  font-weight: bold;
  margin-bottom: 1rem;
  margin-top: 1px;
}
.justify-end{
  justify-content: flex-end;
  margin-left: 13rem;
}
.landing-page {
  background-image: url('@/assets/background.jpg');
  background-size: cover;
  background-position: center;
  min-height: 100vh;
  position: relative;
  color: white;
  text-align: center;
  padding: 2rem;
  overflow: hidden;
}

.bottom-curve {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 150px;
  z-index: 1;
}

.pa-4 {
  background-color: black;
}

.movie-number {
  position: absolute;
  bottom: 8px;
  left: 8px;
  font-size: 4rem;
  font-weight: bold;
  color: white;
  -webkit-text-stroke: 2px black;
  line-height: 1;
  font-family: Impact, sans-serif;
  z-index: 2;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 0;
}

.hero {
  position: relative;
  z-index: 1;
}

.logo {
  height: 45px;
}

.hero {
  margin-top: 10vh;
}

.title {
  font-size: 3rem;
  font-weight: bold;
  margin-bottom: 1rem;
}

.subtitle {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.email-prompt {
  margin-bottom: 1.5rem;
  font-size: 1rem;
}

.email-form {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.email-input {
  padding: 0.75rem;
  font-size: 1rem;
  width: 300px;
  border-radius: 4px;
  border: 2px solid white;
  background-color: transparent;
  color: white;

  ::placeholder {
    color: white;
    opacity: 0.7;
  }
}


.get-started {
  background-color: red;
  color: white;
  font-weight: bold;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  font-family :Arial, Helvetica, sans-serif;
}
</style>
