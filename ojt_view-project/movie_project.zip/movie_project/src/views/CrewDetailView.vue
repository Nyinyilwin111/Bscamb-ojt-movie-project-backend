<template>
<div class="detail-view">
  <v-container fluid>
    <v-row>
      <v-col cols="12" md="3">
        <v-card class="image-card" elevation="6" size="200">
          <v-img :src="posterUrl" alt="Movie Poster" cover class="rounded-image" />
        </v-card>
      </v-col>

      <v-col cols="12" md="9">
        <h2 class="mov-title">{{ crews.name }}</h2>
        <p class="director">{{ crews.role }}</p>
        <p class="birthdate">{{ formattedBirthDate }}</p>
        <br />
        <!-- Description -->
        <p class="description">{{ isExpanded ? fullText : shortText }}</p>
        <span class="toggle" @click="isExpanded = !isExpanded">
          <template v-if="isExpanded">
            less <v-icon small>mdi-chevron-up</v-icon>
          </template>
          <template v-else>
            more <v-icon small>mdi-chevron-down</v-icon>
          </template>
        </span>
      </v-col>
    </v-row>
  </v-container>

</div>
  <div class="second-container">
    <h3 style="color: #fff; padding-left: 20px; ">Movies & Shows on Plex</h3>
    <v-container fluid>
      <v-row>
        <v-col cols="12" v-if="movies.length === 0">
          <p class="text-center" style="color: aliceblue;">No movies found in this category.!</p>
        </v-col>
        <v-col v-for="(movie, index) in moviess" :key="index" cols="12" sm="6" md="4" lg="2">
          <v-img
            :src="movie.image"
            :alt="movie.title"
            cover
            class="responsive-image"
            style="cursor: pointer;"
            @click="nextPage(movie)"
          />
          <p class="movie-name">{{ movie.title }}</p>
          <p class="year">{{ movie.year }}</p>
        </v-col>

      </v-row>
    </v-container>

    <v-container class="plex-container" fluid>
      <v-row align="center" justify="center" class="text-center">
        <v-col cols="12">
          <p class="first" style="color: aliceblue;">Take Plex everywhere</p>
          <p class="second" style="color: aliceblue;">Watch free anytime, anywhere, on almost any device.</p>
        </v-col>
        <v-col cols="12" md="8">
          <v-img
            :src="require('@/assets/device.png')"
            alt="Devices"
            class="device-image"
            width="100%"
            contain
          />
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>
<script setup>
import { ref, computed,watch  } from 'vue'
import { useStore } from 'vuex'
import api from '@/utils/api.js'
import { useRouter } from 'vue-router'
const BASE_URL = 'http://localhost:8082/storage'
import defaultImage from '@/assets/profile.jpg'

const movies = ref([])
const isExpanded = ref(false)
const store = useStore()
const router = useRouter()
const crews = computed(() => store.getters.Get_Crew || {})
watch(
  () => crews.value.name,
  (newName) => {
    if (newName) {
      getmovie(newName)
    }
  },
  { immediate: true }
)
console.log("this is crews:", crews.value)

const fullText = computed(() => crews.value.description || 'No description provided.')
const shortText = computed(() => fullText.value.slice(0, 50))

const posterUrl = computed(() =>
  crews.value.image ? `${BASE_URL}${crews.value.image}` : defaultImage
)

const formattedBirthDate = computed(() => {
  const date = new Date(crews.value.date_of_birth)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',   
    day: 'numeric'
  })
})

async function getmovie(name){
  try {
    const res = await api.get_movie_with_crew_name(`/crew/${name}/movies`)
    const data = await res.json()
    movies.value = data || []
    console.log('Crew fetched:', movies.value)
    console.log('movie image : ',movies.value.movie_poster)
  } catch (err) {
    console.error('Failed to load crew:', err)
  }
}
const moviess = computed(() => {
  return movies.value.map(movie => ({
    title: movie.name,
    image: movie.movie_poster ? `${BASE_URL}${movie.movie_poster}` : '',
    year: new Date(movie.movie_created_date).getFullYear(),
    trailer: movie.trailer ? `${BASE_URL}${movie.trailer}` : '',
    fullMovie: movie.movies ? `${BASE_URL}${movie.movies}` : '',
    description: movie.discuss || '',
    crew: movie.crew || [],
    director: movie.director || 'Unknown Director',
    createdDate: movie.movie_created_date,
    movie_id: movie.id ? movie.id : null,
  }))
})

const nextPage = (movie) => {
  store.dispatch('addMovie', movie)
  router.push('/movie/detail')
}
</script>

<style scoped>
.year,
.movie-name,
.description,
.mov-title {
  color: #fff;
}
.director{
    font-weight: bold;
    font-size: 1.2em;
    font-family:Georgia, 'Times New Roman', Times, serif;
    color:#707070
}
.second-container,
.detail-view {
  position: relative;
  padding: 20px;
  background-color: rgb(45, 45, 45);
}
.toggle {
  color: rgb(203, 98, 18);
  cursor: pointer;
  font-weight: bold;
}

.image-card {
  height: 250px;
  width: 250px;
  overflow: hidden;
  border-radius: 50%;
  margin: auto;

}
.rounded-image {
  height: 100%;
  width: 100%;
  border-radius: 50%;
  border: solid 2px whitesmoke;
  object-fit: cover; 
  size: 200px;
}
.birthdate {
  padding-left: 30px;
  color: #fff;
}
.responsive-image {
  width: 100%;
  height: 9cm;
  border-radius: 8px;
}
.responsive-image:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}
</style>
