<template>
  <div class="landing-page">
    <div class="overlay"></div>
    <v-container class="d-flex justify-center align-center fill-height">
      <v-card class="pa-6" max-width="400" elevation="10" style="background-color: rgba(0, 0, 0, 0.5);">
        <h2 class="text-white mb-6">Sign In</h2>

        <v-form @submit.prevent>
          <v-text-field
            v-model="email"
            label="Email"
            variant="solo"
            class="mb-4"
            color="white"
            density="comfortable"
            bg-color="#1a1a1a"
            hide-details
          />

          <!-- Added Password Field -->
          <v-text-field
            v-model="password"
            label="Password"
            type="password"
            variant="solo"
            class="mb-4"
            color="white"
            density="comfortable"
            bg-color="#1a1a1a"
            hide-details
          />

          <v-btn block color="red" size="large" class="mb-4" @click="loginCheckbtn">
            Sign In
          </v-btn>

          <div v-if="errorMessage" class="text-red-500 mb-4" style="color: red;">{{ errorMessage }}</div>
          <div v-if="successMessage" class="text-green-500 mb-4" style="color: aliceblue;">{{ successMessage }}</div>

          <div class="text-center text-white my-2">OR</div>

          <v-btn block color="#333" class="mb-4">
            Use a Sign-In Code
          </v-btn>

          <div class="d-flex justify-space-between align-center mb-2">
            <v-checkbox v-model="remember" label="Remember me" hide-details color="white" class="text-white" />
            <a href="/forgetPassword" class="text-white text-decoration-underline text-body-2">Forgot password?</a>
          </div>

          <div class="text-white text-body-2 mt-6">
            New to Co-Movie? <a href="/register" class="text-decoration-underline">Sign up now.</a>
          </div>

          <p class="text-white text-caption mt-2">
            This page is protected by Google reCAPTCHA to ensure you're not a bot.
          </p>
        </v-form>
      </v-card>
    </v-container>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { loginCheck } from '@/utils/api.js'  // Adjust path if needed
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'

const userinfo = ref('')
const store = useStore()
const router = useRouter()
const email = ref('')
const password = ref('')  // added password ref
const remember = ref(false)
const errorMessage = ref('')
const successMessage = ref('')

const loginCheckbtn = async () => {
  errorMessage.value = ''
  successMessage.value = ''

  if (!email.value) {
    errorMessage.value = 'Email is required'
    return
  }

  if (!password.value) {
    errorMessage.value = 'Password is required'
    return
  }

  try {
    const user = await loginCheck('/signin', { email: email.value, password: password.value })
    userinfo.value = user
    store.dispatch('addUserInfo', userinfo.value)
    successMessage.value = `Welcome back, ${userinfo.value.name || userinfo.value.email}!`
    console.log('User id is :', userinfo.value.userId)
    localStorage.setItem('user', JSON.stringify(userinfo.value))

    if (userinfo.value.role === 'admin') {
      store.dispatch('userRole', userinfo.value.role)
      successMessage.value = `Welcome ${userinfo.value.role} ${userinfo.value.name || userinfo.value.email}!`
    }
    router.push({ path: '/movies' })

  } catch (error) {
    errorMessage.value = error.message || 'Login failed'
  }
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Edu+QLD+Hand:wght@400..700&family=Fjalla+One&display=swap');
.text-white input {
  color: white !important;
}
.mb-6 {
  font-family: "Fjalla One", sans-serif;
}
.v-input__control {
  border-radius: 4px !important;
}
.landing-page {
  background-image: url('@/assets/background.jpg');
  background-size: cover;
  background-position: center;
  min-height: 100vh;
  padding: 2rem;
  overflow: hidden;
}
.overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 0;
}
</style>
