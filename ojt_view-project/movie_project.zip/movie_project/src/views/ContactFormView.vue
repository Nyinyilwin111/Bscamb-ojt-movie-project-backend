<template>
  <div class="landing-page">
    <v-container class="container">
      <p class="header">CONTACT</p>
      <hr class="hr1">
      <p class="first_text">
        We'd <v-icon color="red" class="mx-1">mdi-heart-multiple-outline</v-icon> to help!
      </p>
      <p class="second_text">
        You can ask us anything you want to know about the content of the movie or the website.
      </p>
      <br />

      <v-container>
        <v-row>
          <v-col cols="12" md="6" class="d-flex flex-column align-end">
            <div class="mb-3">
              <input
                type="email"
                v-model="email"
                class="form-control"
                placeholder="Your Gmail address"
              />
            </div>
            <div class="mb-3">
              <textarea
                class="form-control"
                v-model="message"
                rows="3"
                placeholder="Message"
                @keydown.enter.prevent="sendMessage"
              ></textarea>
            </div>
            <br />
            <v-btn class="btn_send" :disabled="loading" @click="sendMessage">
              {{ loading ? 'Sending...' : 'Send' }}
            </v-btn>
          </v-col>

          <v-col cols="12" md="6">
            <v-card
              class="pa-4"
              style="width: 20rem; height: 15rem; background-color: rgba(255, 255, 255, 0.1); color: #ffffff;"
            >
              <v-row class="align-center mb-3">
                <v-icon color="white" class="mr-2" style="margin-top: 10px;">mdi-map-marker</v-icon>
                <span style="margin-left:20px;">MYANMAR / Yangon</span>
              </v-row>
              <v-row class="align-center mb-3">
                <v-icon color="white" class="mr-2" style="margin-top: 10px;">mdi-phone</v-icon>
                <span style="margin-left:20px;">+95 9 400 851 509</span>
              </v-row>
              <v-row class="align-center">
                <v-icon color="white" class="mr-2" style="margin-top: 10px;">mdi-email</v-icon>
                <span style="margin-left:20px;">nyinyilwin11.mm.com@gmail.com</span>
              </v-row>
              <v-row class="align-center" style="margin-top: 23px;">
                <v-icon color="white" class="mr-2">mdi-facebook</v-icon>
                <span style="font-size: 15px; margin-left: 20px;">
                  https://www.facebook.com/share<br />/1YZH3dKoRD/?mibextid=wwXIfr
                </span>
              </v-row>
              <hr class="hr2" />
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-container>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import emailjs from '@emailjs/browser'

const email = ref('')
const message = ref('')
const loading = ref(false)

onMounted(() => {
  emailjs.init('VOuG0qf2bxpHY_zk0') // Replace with your public key
})

function sendMessage() {
  if (!email.value || !message.value) {
    alert('Please fill in both email and message.')
    return
  }

  loading.value = true

  const templateParams = {
    from_email: email.value,
    message: message.value
  }

  emailjs.send('service_kte9v5h', 'template_s7srqg7', templateParams)
    .then((response) => {
      console.log('SUCCESS!', response.status, response.text)
      alert('Message sent successfully!')
      email.value = ''
      message.value = ''
      console.log('Email:', email.value)
    })
    .catch((error) => {
      console.error('FAILED...', error)
      alert('Something went wrong. Please try again later.')
    })
    .finally(() => {
      loading.value = false
    })
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap');
@import url('https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css');

.header {
  font-family: "Oswald", sans-serif;
  font-size: 3rem;
  font-weight: 400;
  color: #ffffff;
  text-align: center;
}

.first_text {
  font-size: 1rem;
  font-weight: 300;
  color: #ffffff;
  text-align: center;
}

.second_text {
  font-size: 1.1rem;
  font-weight: 300;
  color: #ffffff;
  text-align: center;
  margin-top: 10px;
}

.form-control {
  background-color: rgba(255, 255, 255, 0.8);
  border: none;
  width: 20rem;
  padding: 10px;
  font-size: 1rem;
  color: #333;
}

.hr1 {
  width: 50%;
  height: 1px;
  color: rgb(254, 254, 254);
}

.hr2 {
  width: 100%;
  height: 1px;
  color: rgb(254, 254, 254);
  margin-top: 40px;
}

.landing-page {
  background-image: url('@/assets/contact.jpg');
  background-size: cover;
  background-position: center;
  min-height: 100vh;
  padding: 2rem;
  overflow: hidden;
}

.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.2);
  height: 42rem;
}

.btn_send {
  background-color: #ff0000;
  color: white;
  font-weight: bold;
  width: 8rem;
  height: 2.5rem;
}
</style>
