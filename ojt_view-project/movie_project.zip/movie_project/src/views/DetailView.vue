<template>
  <div class="detail-view" :style="{ backgroundImage: `url(${posterUrl})` }">
    <div class="overlay"></div>
    <v-container fluid>
      <v-row>
        <v-col cols="12" md="3">
          <v-card class="image-card" elevation="4">
            <v-img :src="posterUrl" alt="Movie Poster" cover height="100%" />
          </v-card>
        </v-col>

        <v-col cols="12" md="9">
          <h2 class="mov-title">{{ movieTitle }} ({{ movieYear }})</h2>
          <p class="director">Director : {{ directorCrew.name || 'Unknown Director' }}</p>

          <v-row class="mt-4">
            <v-btn class="play-btn" prepend-icon="mdi-play" @click="fullWatching = true">Watch</v-btn>
            <v-btn class="wishlist" icon :color="isWishlisted ? 'red' : 'white'" @click="toggleWishlist" :aria-pressed="isWishlisted.toString()" aria-label="Add to Wishlist">
              <v-icon>{{ isWishlisted ? 'mdi-bookmark' : 'mdi-bookmark-outline' }}</v-icon>
            </v-btn>
            <v-btn class="trailer" @click="isWatching = true" prepend-icon="mdi-movie-roll">Trailer</v-btn>
          </v-row>

          <br />

          <p class="description">{{ isExpanded ? fullText : shortText }}</p>
          <span class="toggle" @click="isExpanded = !isExpanded">
            <template v-if="isExpanded">
              less <v-icon small>mdi-chevron-up</v-icon>
            </template>
            <template v-else>
              more <v-icon small>mdi-chevron-down</v-icon>
            </template>
          </span>

          <div v-if="isWatching" class="video-overlay">
            <div class="video-wrapper">
              <video controls autoplay class="video-element">
                <source :src="movietrailerUrl" type="video/mp4" />
              </video>
              <v-btn icon class="close-btn" @click="isWatching = false">
                <v-icon>mdi-close</v-icon>
              </v-btn>
            </div>
          </div>

          <div v-if="fullWatching" class="video-overlay">
            <div class="video-wrapper">
              <video :src="movieVideoUrl" controls autoplay class="video-element"></video>
              <v-btn icon class="close-btn" @click="fullWatching = false">
                <v-icon>mdi-close</v-icon>
              </v-btn>
            </div>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>

  <div class="second-con">
    <v-container fluid>
      <h2 class="text-white font-weight-bold text-h4 mb-4">Cast & Crew</h2>
      <v-slide-group v-model="currentIndex" class="cast-group" center-active show-arrows>
        <v-slide-group-item
          v-for="(member, index) in crews"
          :key="index"
          :class="{ 'last-slide': index === crews.length - 1 }"
        >
          <div class="cast-card">
            <v-avatar size="170" class="crew-avatar" @click="nextPage(member)">
              <v-img :src="getImageUrl(member.image)" :alt="member.name" />
            </v-avatar>
            <div class="name">{{ member.name }}</div>
            <div class="role">{{ member.role }}</div>
          </div>
        </v-slide-group-item>
      </v-slide-group>
    </v-container>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import api from '@/utils/api.js'

const store = useStore()
const router = useRouter()
const BASE_URL = 'http://localhost:8082/storage'

const movie = computed(() => store.getters.GET_ADD_MOVIE || {})
const userinfo = computed(() => store.getters.GET_USER_INFO || {})
const isWatching = ref(false)
const isWishlisted = ref(false)
const fullWatching = ref(false)
const isExpanded = ref(false)
const currentIndex = ref(0)
const crews = ref([])

const posterUrl = computed(() => movie.value.image || require('@/assets/background.jpg'))
const movieVideoUrl = computed(() => movie.value.fullMovie || null)
const movietrailerUrl = computed(() => movie.value.trailer || null)
const movieTitle = computed(() => movie.value.title || 'Untitled')
const movieYear = computed(() => (typeof movie.value.year === 'number' && movie.value.year > 1900 ? movie.value.year : 'N/A'))
const fullText = movie.value.description || 'No description provided.'
const shortText = fullText.slice(0, 50)
const movieId = movie.value.movie_id
const userId = userinfo.value.userId

const directorCrew = computed(() => crews.value.find(m => m.role?.toLowerCase().includes('director')) || {})

watch(
  () => movie.value?.movie_id,
  (newId) => newId && getCrew(newId),
  { immediate: true }
)
// 1. Declare function first
const loadWishlistStatus = async () => {
  try {
    if (!movieId || !userId) return;

    const existing = await api.checkWishlist(`/check/${movieId}/${userId}`);
    console.log('Wishlist status:', existing);
   if(existing.success == true && existing.like == 1) {
      isWishlisted.value = true;
    } else {
      isWishlisted.value = false;
    }
  } catch (err) {
    console.error('Failed to load wishlist status:', err);
    isWishlisted.value = false;
  }
};

// 2. Use in watch after declaration
watch(
  () => [movie.value?.movie_id, userinfo.value?.userId],
  ([newMovieId, newUserId]) => {
    if (newMovieId && newUserId) {
      loadWishlistStatus();
    }
  },
  { immediate: true }
);

async function getCrew(id) {
  try {
    const res = await api.get_crew_with_movie_id(`/crew/${id}`)
    const data = await res.json()
    crews.value = data || []
  } catch (err) {
    console.error('Failed to load crew:', err)
  }
}

const toggleWishlist = async () => {
  try {
    if (!movieId || !userId) {
      console.warn('Missing movieId or userId for wishlist toggle');
      return;
    }

    const existing = await api.checkWishlist(`/check/${movieId}/${userId}`);

    const isExisting = existing && existing.id;
    const trendId = existing?.id;
    const newLikeValue = isExisting && existing.like === 1 ? 0 : 1;

    const payload = {
      like: newLikeValue,
      movie_id: movieId,
      user_id: userId,
    };

    if (isExisting && trendId) {
      console.log('Payload:', payload);
      await api.updateWishlist(`/update/${trendId}`, payload);
    } else {
      await api.addWishlist('/save', payload);
    }

    isWishlisted.value = newLikeValue === 1;

  } catch (err) {
    console.error('Error toggling wishlist:', err);
  }
};

const nextPage = (member) => {
  store.dispatch('addCrews', member)
  router.push('/crew/detail')
}

const getImageUrl = (path) => path ? `${BASE_URL}${path}` : require('@/assets/profile.jpg')

</script>

<style scoped>

.detail-view {
  padding: 20px;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  min-height: 100vh;
  color: #fff;
}
.detail-view .v-container {
  position: relative;
  z-index: 2;
}
.second-con .v-container {
  position: relative;
  z-index: 2;
}
.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7); 
  z-index: 1;
}
.image-card {
  height: 30rem;
  overflow: hidden;
  border-radius: 10px;
}
.mov-title {
  font-size: 2rem;
  color: #fff;
  font-weight: bold;
}
.director {
  font-size: 1.2rem;
  color: #cccccc;
}
.play-btn {
  background-color: #ffffff;
  color: black;
  font-weight: bold;
  font-size: 15px;
  border-radius: 20px;
  width: 120px;
  height: 40px;
}
.play-btn:hover {
  background-color: #b4b4b4;
}
.wishlist {
  width: 40px;
  height: 40px;
  margin-left: 10px;
  border-radius: 50%;
}
.trailer {
  background-color: #fff;
  color: #000;
  font-weight: bold;
  font-size: 15px;
  border-radius: 20px;
  margin-left: 10px;
}

.trailer:hover {
  background-color: #b4b4b4;
}
.description {
  white-space: pre-line;
  font-size: 16px;
  line-height: 1.5;
  color: #ffffff;
}
.toggle {
  color: rgb(203, 98, 18);
  cursor: pointer;
  font-weight: bold;
}
.second-con {
  background-color: rgba(0, 0, 0, 0.6);
  padding: 30px 10px;
}
.cast-card {
  text-align: center;
  padding: 10px;
  width: 180px;
}
.name {
  font-weight: bold;
  margin-top: 8px;
  font-size: 0.9rem;
}
.role {
  font-size: 0.75rem;
  color: #ccc;
}
.video-overlay {
  margin-top: 25px;
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 9999;
  background-color: rgba(0, 0, 0, 0.9);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.video-wrapper {
  position: relative;
  width: 90%;
  max-width: 1000px;
}

.video-element {
  width: 100%;
  height: auto;
  border-radius: 12px;
}

.close-btn {
  position: absolute;
  top: -20px;
  right: -20px;
  background-color: white;
  color: black;
  z-index: 10000;
  border-radius: 50%;
}
.crew-avatar:hover {
  transform: scale(1.05);
  transition: transform 0.3s;
  size: 179px;
  border: 3px solid aqua;
  cursor: pointer;
}

</style>
