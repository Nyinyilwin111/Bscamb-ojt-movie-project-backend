<template>
  <div class="container">
    <form @submit.prevent="submitForm">
      <div class="row">
        <!-- Movie Form -->
        <div class="col-md-6 movie-form-wrapper">
          <div class="form-container">
            <h2 class="form-title">Add New Movie</h2>

            <div class="form-group">
              <label>Movie Name</label>
              <input v-model="movie.name" class="form-control" type="text" required placeholder="Movie name" />
            </div>

            <div class="form-group">
              <label>Category</label>
              <select v-model="movie.category" class="form-control" required>
                <option disabled value="" class="form-control">Please select a category</option>
                <option
                  v-for="cat in categories"
                  :key="cat.c_id"
                  :value="cat.categoryName"
                  style="color: black"
                >
                  {{ cat.categoryName }}
                </option>
              </select>
            </div>

            <div class="form-group">
              <label>Trailer (MP4)</label>
              <input type="file" @change="handleTrailerUpload" accept="video/mp4" required />
            </div>

            <div class="form-group">
              <label>Full Movie (MP4)</label>
              <input type="file" @change="handleFullMovieUpload" accept="video/mp4" required class="form-control" />
            </div>

            <div class="form-group">
              <label>Poster Image</label>
              <input type="file" @change="handleImageUpload" accept="image/*" required class="form-control" />
              <div v-if="posterPreview" class="poster-preview">
                <img :src="posterPreview" alt="Poster Preview" />
              </div>
            </div>

            <div class="form-group">
              <label>Created Date</label>
              <input type="date" v-model="rawDate" @change="formatDate" required class="form-control" />
              <small class="text-muted">Formatted: {{ movie.createdDate }}</small>
            </div>

            <div class="form-group">
              <label>Short Description</label>
              <textarea v-model="movie.description" rows="4" required class="form-control"></textarea>
            </div>

            <button type="submit" class="submit-button" >Submit Movie & Crew</button>
          </div>
        </div>

        <!-- Crew Form -->
        <div class="col-md-6 crew-form-wrapper">
          <v-card class="pa-4 mb-2" elevation="3">
            <v-card-title>Movie Crew</v-card-title>
            <v-divider></v-divider>

            <div v-for="(crew, index) in crews" :key="index" class="mb-6">
              <v-card class="pa-3 mb-2" outlined>
                <v-row>
                  <!-- Crew Name -->
                  <v-col cols="12" md="6">
                    <v-text-field
                      v-model="crew.name"
                      label="Crew Name"
                      :rules="[rules.required]"
                      placeholder="Enter crew name"
                      @blur="checkIfCrewExists(index)"
                    />
                  </v-col>

                  <!-- Status Message -->
                  <v-col cols="12" md="6" class="d-flex align-center">
                    <small v-if="crew.isExisting === true" class="text-success" style="font-weight: 600;">
                      ✔ Crew already exists. Only role is required.
                    </small>
                    <small v-else-if="crew.isExisting === false" class="text-warning" style="font-weight: 600;">
                      ✍ New crew. Please fill out all details.
                    </small>
                  </v-col>

                  <!-- Role (always visible) -->
                  <v-col cols="12" md="6">
                    <v-text-field
                      v-model="crew.role"
                      label="Role"
                      :rules="[rules.required]"
                      placeholder="Enter role"
                    />
                  </v-col>

                  <!-- Other fields: show only if crew is new -->
                  <template v-if="crew.isExisting === false">
                    <v-col cols="12" md="6">
                      <v-text-field v-model="crew.dob" label="Date of Birth" type="date" />
                    </v-col>

                    <v-col cols="12" md="6">
                      <label>Profile Image</label>
                      <input
                        type="file"
                        @change="handleCrewImageUpload($event, index)"
                        accept="image/*"
                        required
                      />
                      <div v-show="crew.image" class="poster-preview mt-2">
                        <img :src="crew.image" alt="Crew Image Preview" />
                      </div>
                    </v-col>

                    <v-col cols="12" md="6">
                      <v-text-field v-model="crew.link" label="Link (e.g.http://..)" />
                    </v-col>

                    <v-col cols="12">
                      <v-textarea v-model="crew.description" label="Description" rows="2" />
                    </v-col>
                  </template>

                  <!-- Delete button -->
                  <v-col cols="12" class="text-right">
                    <v-btn icon color="red" v-if="crews.length > 1" @click="removeCrew(index)">
                      <v-icon>mdi-delete</v-icon>
                    </v-btn>
                  </v-col>
                </v-row>
              </v-card>
            </div>

            <v-btn color="primary" @click="addCrew" class="mb-4">
              <v-icon left>mdi-plus</v-icon> Add Another Crew
            </v-btn>
          </v-card>
        </div>

      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '@/utils/api'

const rawDate = ref('')
const posterPreview = ref(null)
const categories = ref([])
const crewses = ref([])

// Movie form data
const movie = ref({
  name: '',
  category: '',
  description: '',
  trailer: null,
  fullMovie: null,
  poster: null,
  createdDate: ''
})

// Crew form list
const crews = ref([
  {
    name: '',
    role: '',
    dob: '',
    description: '',
    link: '',
    imageFile: null,
    image: null,
    isExisting: null
  }
])

// Validation rule
const rules = {
  required: (v) => !!v || 'Required field'
}

// Load all crews on mount
onMounted(async () => {
  try {
    const res = await api.checkCrewExists('/exists')
    const data = await res.json()
    crewses.value = data
  } catch (err) {
    console.error('Failed to load crews', err)
  }
})

// Load all categories on mount
onMounted(async () => {
  try {
    const res = await api.get_AllCategory('/getAllCategory')
    const data = await res.json()
    categories.value = data
  } catch (err) {
    console.error('Failed to load categories', err)
  }
})

function checkIfCrewExists(index) {
  const name = crews.value[index].name.trim().toLowerCase()
  crews.value[index].isExisting = crewses.value.some(
    c => c.name.trim().toLowerCase() === name
  )
}

const uploadFile = async (file) => {
  if (!file) throw new Error("Upload failed: file is null or undefined.")
  const formData = new FormData()
  formData.append("file", file)
  formData.append("fileType", file.type)

  const res = await fetch("http://localhost:8082/storage/upload", {
    method: "POST",
    body: formData
  })
  if (!res.ok) {
    const errorText = await res.text()
    throw new Error("Upload failed: " + errorText)
  }
  return await res.text()
}

function handleImageUpload(e) {
  const file = e.target.files[0]
  if (file) {
    movie.value.poster = file
    posterPreview.value = URL.createObjectURL(file)
  }
}

function handleTrailerUpload(e) {
  const file = e.target.files[0]
  if (file) {
    movie.value.trailer = file
  }
}

function handleFullMovieUpload(e) {
  const file = e.target.files[0]
  if (file) {
    movie.value.fullMovie = file
  }
}

function handleCrewImageUpload(e, index) {
  const file = e.target.files[0]
  if (file) {
    crews.value[index].imageFile = file
    const reader = new FileReader()
    reader.onload = () => (crews.value[index].image = reader.result)
    reader.readAsDataURL(file)
  }
}

function addCrew() {
  crews.value.push({
    name: '',
    role: '',
    dob: '',
    description: '',
    link: '',
    imageFile: null,
    image: null,
    isExisting: null
  })
}

function removeCrew(index) {
  crews.value.splice(index, 1)
}

function formatDate() {
  const d = new Date(rawDate.value)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  movie.value.createdDate = `${y}-${m}-${day}`
}

async function submitForm() {
  try {
    if (!movie.value.poster || !movie.value.trailer || !movie.value.fullMovie) {
      alert("Please select poster, trailer, and full movie files.")
      return
    }
    const posterPath = await uploadFile(movie.value.poster)
    const trailerPath = await uploadFile(movie.value.trailer)
    const fullMoviePath = await uploadFile(movie.value.fullMovie)

    const crewImagePaths = []
    for (let i = 0; i < crews.value.length; i++) {
      const file = crews.value[i].imageFile
      if (!file && crews.value[i].isExisting === false) {
        alert(`Missing image file for crew #${i + 1}`)
        return
      }
      const path = file ? await uploadFile(file) : null
      crewImagePaths.push(path)
    }

    const cleanedCrews = crews.value.map((c, i) => ({
      name: c.name,
      role: c.role,
      date_of_birth: c.dob,
      description: c.description,
      link: c.link,
      image: crewImagePaths[i]
    }))

    const payload = {
      name: movie.value.name,
      description: movie.value.description,
      movie_poster: posterPath,
      trailer: trailerPath,
      movies: fullMoviePath,
      movie_created_date: movie.value.createdDate,
      category: { categoryName: movie.value.category },
      crews: cleanedCrews
    }

    const res = await api.movieSave('/save', JSON.stringify(payload), true)
    const text = await res.text()

    if (res.ok) {
      alert("Movie saved successfully")
      resetForm()
    } else {
      alert("Error: " + text)
    }
  } catch (err) {
    console.error("Error during submission:", err)
    alert("Failed to submit movie: " + err.message)
  }
}

function resetForm() {
  movie.value = {
    name: '',
    category: '',
    description: '',
    trailer: null,
    fullMovie: null,
    poster: null,
    createdDate: ''
  }
  rawDate.value = ''
  posterPreview.value = null
  crews.value = [
    {
      name: '',
      role: '',
      dob: '',
      description: '',
      link: '',
      imageFile: null,
      image: null,
      isExisting: null
    }
  ]
}
</script>


<style scoped>
.movie-form-wrapper,
.crew-form-wrapper {
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.form-container {
  display: flex;
  flex-direction: column;
}

.form-title {
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 16px;
}

input,
textarea {
  width: 100%;
  padding: 8px 12px;
  font-size: 15px;
  border-radius: 6px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

textarea {
  resize: vertical;
}

.poster-preview {
  margin-top: 8px;
}

.poster-preview img {
  width: 100%;
  max-height: 180px;
  object-fit: contain;
  border-radius: 6px;
  border: 1px solid #ccc;
}

.submit-button {
  background-color: #007bff;
  color: white;
  padding: 10px 16px;
  border: none;
  border-radius: 6px;
  margin-top: 12px;
  width: 100%;
  cursor: pointer;
  font-weight: 600;
  transition: background-color 0.3s;
}

.submit-button:hover {
  background-color: #0056b3;
}

@media (max-width: 768px) {
  .movie-form-wrapper,
  .crew-form-wrapper {
    width: 100%;
  }
}
</style>
<!-- <script setup>
import { ref, onMounted } from 'vue'
import api from '@/utils/api'

// Movie form data
const movie = ref({
  name: '',
  category: '',
  description: '',
  crew_role: crews.value[0].role || '',
  trailer: null,
  fullMovie: null,
  poster: null,
  createdDate: ''
})

const rawDate = ref('')
const posterPreview = ref(null)
const categories = ref([])

// Crew form
const crews = ref([
  {
    name: '',
    role: '',
    dob: '',
    description: '',
    link: '',
    imageFile: null,
    image: null
  }
])

// Validation rule
const rules = {
  required: (v) => !!v || 'Required field'
}

// Load all categories
onMounted(async () => {
  try {
    const res = await api.get_AllCategory('/getAllCategory')
    const data = await res.json()
    categories.value = data
  } catch (err) {
    console.error('Failed to load categories', err)
  }
})

// Upload file using backend format (file + fileType)
const uploadFile = async (file) => {
  if (!file) {
    throw new Error("Upload failed: file is null or undefined.");
  }

  const formData = new FormData();
  formData.append("file", file);
  formData.append("fileType", file.type);

  const res = await fetch("http://localhost:8082/storage/upload", {
    method: "POST",
    body: formData
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error("Upload failed: " + errorText);
  }

  return await res.text();
};

// Input file handlers
function handleImageUpload(e) {
  const file = e.target.files[0];
  if (file) {
    movie.value.poster = file;
    posterPreview.value = URL.createObjectURL(file);
  }
}

function handleTrailerUpload(e) {
  const file = e.target.files[0];
  if (file) {
    movie.value.trailer = file;
  }
}

function handleFullMovieUpload(e) {
  const file = e.target.files[0];
  if (file) {
    movie.value.fullMovie = file;
  }
}

function handleCrewImageUpload(e, index) {
  const file = e.target.files[0];
  if (file) {
    crews.value[index].imageFile = file;
    const reader = new FileReader();
    reader.onload = () => (crews.value[index].image = reader.result);
    reader.readAsDataURL(file);
  }
}

// Add/remove crew
function addCrew() {
  crews.value.push({
    name: '',
    role: '',
    dob: '',
    description: '',
    link: '',
    imageFile: null,
    image: null
  })
}

function removeCrew(index) {
  crews.value.splice(index, 1)
}

// Format Date (yyyy-MM-dd)
function formatDate() {
  const d = new Date(rawDate.value)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  movie.value.createdDate = `${y}-${m}-${day}`
}

// Final form submission
async function submitForm() {
  try {
    // Validate movie files
    if (!movie.value.poster || !movie.value.trailer || !movie.value.fullMovie) {
      alert("Please select poster, trailer, and full movie files.");
      return;
    }

    console.log("Uploading poster:", movie.value.poster.name);
    const posterPath = await uploadFile(movie.value.poster);

    console.log("Uploading trailer:", movie.value.trailer.name);
    const trailerPath = await uploadFile(movie.value.trailer);

    console.log("Uploading full movie:", movie.value.fullMovie.name);
    const fullMoviePath = await uploadFile(movie.value.fullMovie);

    // Upload each crew profile image
    const crewImagePaths = [];
    for (let i = 0; i < crews.value.length; i++) {
      const file = crews.value[i].imageFile;
      if (file) {
        console.log(`Uploading crew[${i}] image:`, file.name);
        const path = await uploadFile(file);
        crewImagePaths.push(path);
      } else {
        alert(`Missing image file for crew #${i + 1}`);
        return;
      }
    }

    // Build cleaned crew data
    const cleanedCrews = crews.value.map((c, i) => ({
      name: c.name,
      role: c.role,
      date_of_birth: c.dob,
      description: c.description,
      link: c.link,
      image: crewImagePaths[i]
    }));

    // Final payload
    const payload = {
      name: movie.value.name,
      description: movie.value.description,
      crew_role: movie.value.crew_role,
      movie_poster: posterPath,
      trailer: trailerPath,
      movies: fullMoviePath,
      movie_created_date: movie.value.createdDate,
      category: { categoryName: movie.value.category },
      crews: cleanedCrews
    };

    // Submit to backend
    const res = await api.movieSave('/save', JSON.stringify(payload), true);
    const text = await res.text();

    if (res.ok) {
      alert("Movie saved successfully");
      resetForm();
    } else {
      alert("Error: " + text);
    }

  } catch (err) {
    console.error("Error during submission:", err);
    alert("Failed to submit movie: " + err.message);
  }
}

function resetForm() {
  movie.value = {
    name: '',
    category: '',
    crew_role: '',
    description: '',
    trailer: null,
    fullMovie: null,
    poster: null,
    createdDate: ''
  }
  rawDate.value = ''
  posterPreview.value = null
  crews.value = [{
    name: '',
    // role: '',
    dob: '',
    description: '',
    link: '',
    imageFile: null,
    image: null
  }]
}
</script> -->
