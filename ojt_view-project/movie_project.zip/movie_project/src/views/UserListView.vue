<template>
  <div class="background">
    <div v-if="isError" class="error-overlay">
      <div class="error-message">
        {{ errorMessage }}
      </div>
    </div>

    <v-sheet border rounded>
      <v-data-table
        :headers="headers"
        :hide-default-footer="user.length < 11"
        :items="user"
      >
      <!-- eslint-disable-next-line vue/valid-v-slot -->
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>
              <v-icon color="medium-emphasis" icon="mdi-book-multiple" size="x-small" start></v-icon>
              User Lists
            </v-toolbar-title>
          </v-toolbar>
        </template>
        <!-- eslint-disable-next-line vue/valid-v-slot -->
        <template v-slot:item.image="{ item }">
          <v-avatar
            size="60"
            class="mx-auto my-2 elevation-2"
            rounded="circle"
          >
            <v-img
              :src="fixImagePath(item.image)"
              alt="User Image"
              cover
            />
          </v-avatar>
        </template>

        <!-- eslint-disable-next-line vue/valid-v-slot -->
        <template v-slot:item.actions="{ item }">
          <div class="d-flex ga-2 justify-end">
            <v-btn @click="edit(item.userId)">
              {{ item.status === 'active' ? 'BLOCK' : 'UNBLOCK' }}
            </v-btn>

          </div>
        </template>

        <template v-slot:no-data>
          <v-btn prepend-icon="mdi-backup-restore" rounded="lg" text="Reset data" variant="text" border @click="reset" />
        </template>
      </v-data-table>
    </v-sheet>

  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '@/utils/api'

const isError = ref(false)
const errorMessage = ref('')
const statusMessage = ref('')
const redirectUrl = '/user/lists'
const user = ref([])
import defaultProfile from '@/assets/profile.jpg';

const headers = [
  { title: 'Name', key: 'name' },
  { title: 'Profile', key: 'image' },
  { title: 'Gmail', key: 'gmail', align: 'center' },
  { title: 'Role', key: 'role', align: 'top' },
  { title: 'Joined Date', key: 'joined_date', align: 'center' },
  { title: 'Status', key: 'status', align: 'center' },
  { title: 'Actions', key: 'actions', sortable: false , align: 'end' }
]
// 
onMounted(async () => {
  try {
    const resp = await api.get_AllUser("/getuser")  
    const data = await resp.json()

    if (resp.ok && data) {
      user.value = data
      console.log("User data fetched successfully:", user.value)
    } else {
      handleError(resp.status, resp.statusText)
    }
  } catch (err) {
    isError.value = true
    errorMessage.value = "Server is unreachable. Please try again later."
    setTimeout(() => {
      window.location.href = redirectUrl
    }, 3000)
  }
})

// Image path fixer
const fixImagePath = (path) => {
  if (!path) return defaultProfile

 return `http://localhost:8082/storage${path}`
}
function handleError(status, statusText) {
  isError.value = true
  if (status === 404) {
    errorMessage.value = "Error 404: Resource Not Found"
  } else if (status === 401) {
    errorMessage.value = "Error 401: Unauthorized"
  } else if (status === 500) {
    errorMessage.value = "Error 500: Server error. Try again later."
  } else {
    errorMessage.value = `Error ${status}: ${statusText}`
  }
  setTimeout(() => {
    window.location.href = redirectUrl
  }, 3000)
}

// console.log("Role in user list view:", user.value.role)

async function edit(id) {
  const selected = user.value.find(u => u.userId === id) 
  console.log("Selected user for edit:", selected)
  if (selected) {
    const newStatus = selected.status == 'active' ? 'block' : 'active'
    console.log("Updating user status...", selected.userId, newStatus)
    console.log("name "+selected.name)
    console.log("gmail "+selected.gmail)
    console.log("user id "+selected.userId)
    console.log("status "+selected.status)

    // Convert to backend-compatible format
    const updatedUserstatus = {
      userId: selected.userId, 
      status: newStatus
        
    }

    try {
      console.log("user of role in user list of update status", selected.role)
      if(selected.role == 'user'){
        const resp = await api.update("/updatestatus", updatedUserstatus)
        if (resp && resp.ok) {
          selected.status = newStatus
          statusMessage.value = `User ${newStatus === 'block' ? 'blocked' : 'unblocked'} successfully.`
        }
      } else {
        isError.value = true
        errorMessage.value = "This user cannot be blocked or unblocked .! Because this user is an admin."
        setTimeout(() => {
          window.location.href = redirectUrl
        }, 3000)
      }
    } catch (err) {
      isError.value = true
      errorMessage.value = "Failed to update user status."
    }
  }
}


</script>

<style scoped>
.background {
  background-color: rgb(152, 110, 110);
  min-height: 100vh;
  padding: 5px 5px 2rem;
  position: relative;
}

.error-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgba(157, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.error-message {
  color: rgb(99, 7, 7);
  font-size: 2rem;
  font-weight: 800;
  padding: 20px 40px;
  text-shadow: 0 0 10px red;
}
</style>
