const localhost = "http://localhost:8082/user"
const categorylocalhost = "http://localhost:8082/category"
const movielocalhost = "http://localhost:8082/movie"
const crewlocalhost = "http://localhost:8082/crew"
const crewwithmIdlocalhost = "http://localhost:8082/movie_crew"
const TrendMoviehost = "http://localhost:8082/trendMovie"

// this movie API base URL
export async function movieSave(path, data, isJson = false) {
  const headers = isJson ? { "Content-Type": "application/json" } : {}
  const response = await fetch(movielocalhost + path, {
    method: "POST",
    headers,
    body: data
  })
  return response
}

export async function get_AllMovies(path) {
  try {
    const response = await fetch(movielocalhost + path, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    })
    return response
  } catch (err) {
    console.error('Fetch error:', err)
    return null
  }
}
export async function getMovieswithCategory(path) {
  try {
    const response = await fetch(movielocalhost + path, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    })
    return response
  } catch (err) {
    console.error('Fetch error:', err)
    return null
  }
}

export async function delete_Movie(path) {
  try {
    const response = await fetch(movielocalhost + path, {
      method: 'DELETE',
    })
    return response
  } catch (err) {
    console.error('Delete error:', err)
    return null
  }
}

export async function trendMovie(path) {
  try {
    const response = await fetch(TrendMoviehost + path, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    })
    return response
  } catch (err) {
    console.error('Fetch error:', err)
    return null
  }
}


// crew section
 export async function get_crew_with_movie_id(path) {
   try {
     const response = await fetch(crewwithmIdlocalhost + path, {
       method: 'GET',
       headers: { Accept: 'application/json' },
     })
     return response
   } catch (err) {
     console.error('Fetch error:', err)
     return null
   }
 }
export async function get_movie_with_crew_name(path) {
   try {
     const response = await fetch(movielocalhost + path, {
       method: 'GET',
       headers: { Accept: 'application/json' },
     })
     return response
   } catch (err) {
     console.error('Fetch error:', err)
     return null
   }
 }
export async function checkCrewExists(path) {
   try {
     const response = await fetch(crewlocalhost + path, {
       method: 'GET',
       headers: { Accept: 'application/json' },
     })
     return response
   } catch (err) {
     console.error('Fetch error:', err)
     return null
   }
 }

// user section 
export async function save(path, formData) {
  try {
    const resp = await fetch(localhost + path, {
      method: "POST",
      body: formData
    })
    return resp
  } catch (error) {
    console.error("Error in API save:", error)
    throw error
  }
}
export async function imageUpload(path, formData) {
  try {
    const resp = await fetch(localhost + path, {
      method: "PUT",
      body: formData,
    })
    return resp
  } catch (error) {
    console.error("Error in API save:", error)
    throw error
  }
}
export async function getImageWithId(path) {
  try {
    const resp = await fetch(localhost + path, {
      method: "GET",
      headers: { Accept: 'application/json' }
    })
    return resp
  } catch (error) {
    console.error("Error in API get image:", error)
    throw error
  }
}

// Get all categories
async function get_AllCategory(path) {
  try {
    const response = await fetch(categorylocalhost + path, {
      method: "GET",
      headers: { Accept: "application/json" }
    })
    return response
  } catch (err) {
    console.log(err)
    return null
  }
}

// Get all users (optional)
async function get_AllUser(path) {
  try {
    const response = await fetch(localhost + path, {
      method: "GET",
      headers: { Accept: "application/json" }
    })
    return response
  } catch (err) {
    console.log(err)
    return null
  }
}

// Update user
async function update(path, api_user) {
  try {
    const resp = await fetch(localhost + path, {
      method: 'PUT',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(api_user)
    })
    return resp
  } catch (error) {
    console.log(error)
    return null
  }
}

// Delete user
async function deletion(path) {
  try {
    const resp = await fetch(localhost + path, {
      method: 'DELETE',
      headers: { "Content-Type": "application/json" }
    })
    return resp
  } catch (error) {
    console.log(error)
    return null
  }
}

// Login
export async function loginCheck(path, api_user) {
  try {
    const response = await fetch(localhost + path, {
      method: 'POST',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(api_user)
    })

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}))
      throw new Error(`Login failed: ${response.status} - ${errorBody.message || response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error in loginCheck:", error)
    throw error
  }
}

// trending movies and wishlist
export async function addWishlist(path, api_user) {
  try {
    const response = await fetch(TrendMoviehost + path, {
      method: 'POST',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(api_user)
    })

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}))
      throw new Error(`Wishlist failed: ${response.status} - ${errorBody.message || response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error in wishlist:", error)
    throw error
  }
}
export async function updateWishlist(path, api_user) {
  try {
    const response = await fetch(TrendMoviehost + path, {
      method: 'PUT',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(api_user)
    })

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}))
      throw new Error(`Wishlist update failed: ${response.status} - ${errorBody.message || response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error in wishlist update:", error)
    throw error
  }
}
export async function checkWishlist(path) {
  try {
    const response = await fetch(TrendMoviehost + path, {
      method: 'GET',             
      headers: { "Content-Type": "application/json" },
    })

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}))
      throw new Error(`Wishlist get failed: ${response.status} - ${errorBody.message || response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error in wishlist get:", error)
    throw error
  }
}

export default {
  get_AllUser,
  get_AllCategory,
  movieSave,
  save,
  update,
  deletion,
  loginCheck,
  get_AllMovies,
  delete_Movie,
  trendMovie,
  getMovieswithCategory,
  get_crew_with_movie_id,
  get_movie_with_crew_name,
  checkCrewExists,
  imageUpload,
  getImageWithId,
  addWishlist,
  updateWishlist,
  checkWishlist
}
