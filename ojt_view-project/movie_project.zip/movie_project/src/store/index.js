import { createStore } from 'vuex'

export default createStore({
  state: {
    login: !!localStorage.getItem("user"),
    category: '',
    userRole: '',
    movie: '',
    crews: {},
    userinfo: JSON.parse(localStorage.getItem("user")) || {} 
  },

  getters: {
    GET_CATEGORY: (state) => state.category,

    Get_Login_State: (state) => state.login,

    GET_USERROLE: (state) => state.userRole,

    Get_Crew: (state) => state.crews,

    GET_USER_INFO: (state) => state.userinfo, 

    GET_ADD_MOVIE: (state) => state.movie
  },

  mutations: {
    SET_CATEGORY(state, category) {
      state.category = category
    },

    Login_State_Change(state) {
      state.login = !state.login
      // Removed localStorage line — login should not be stored as boolean
      console.log('Login state toggled:', state.login)
    },

    LogOut_State_Change(state) {
      state.login = false
      state.userinfo = {}
      localStorage.removeItem("user")
    },

    User_Role(state, userRole) {
      state.userRole = userRole
    },

    SET_MOVIE(state, movie) {
      state.movie = movie
    },

    SET_CREW(state, crews) {
      state.crews = crews
    },

    SET_USER_INFO(state, userinfo) {
      state.userinfo = userinfo
      state.login = true 
      localStorage.setItem("user", JSON.stringify(userinfo)) 
    }
  },

  actions: {
    LoginStateChange({ commit }) {
      commit("Login_State_Change")
    },

    LogOutStateChange({ commit }) {
      commit("LogOut_State_Change")
    },

    addToCategory({ commit }, category) {
      commit('SET_CATEGORY', category)
    },

    userRole({ commit }, userRole) {
      commit('User_Role', userRole)
    },

    addMovie({ commit }, movie) {
      commit('SET_MOVIE', movie)
    },

    addCrews({ commit }, crews) {
      commit('SET_CREW', crews)
    },

    addUserInfo({ commit }, userinfo) {
      commit('SET_USER_INFO', userinfo)
    }
  },

  modules: {}
})
