<template>
  <v-app>
    <v-app-bar flat app :class="['custom-navbar', appBarClass]">
      <v-container fluid class="d-flex align-center">
        <!-- Logo -->
        <div class="logo">
          <span class="logo-primary">CO</span><span class="logo-secondary">-MOVIE</span>
        </div>

        <!-- Search box -->
        <input
          v-model="search"
          class="search-box"
          placeholder="Search Crime Titles"
          @focus="showResults = true"
          @blur="hideResults"
          autocomplete="off"
        />

        <!-- Home Button -->
        <v-btn prepend-icon="mdi-home-city" class="home" to="/">Home</v-btn>

        <!-- Movies Dropdown -->
        <v-menu open-on-hover offset-y transition="scale-transition" max-width="600">
          <template #activator="{ props }">
            <v-btn prepend-icon="mdi-movie" class="movie" v-bind="props">Movies</v-btn>
          </template>
          <v-list>
            <v-list-subheader class="text-h5">Categories</v-list-subheader>
            <v-row>
              <v-col cols="12" md="6">
                <v-list-item>
                  <v-list-item-title @click="goToCategory('Animation')" class="list">Animation</v-list-item-title>
                </v-list-item>
                <v-list-item>
                  <v-list-item-title @click="goToCategory('Crime')" class="list">Crime</v-list-item-title>
                </v-list-item>
              </v-col>
              <v-col cols="12" md="6">
                <v-list-item>
                  <v-list-item-title @click="goToCategory('Drama')" class="list">Drama</v-list-item-title>
                </v-list-item>
                <v-list-item>
                  <v-list-item-title @click="goToCategory('Action')" class="list">Action</v-list-item-title>
                </v-list-item>
              </v-col>
            </v-row>
          </v-list>
        </v-menu>

        <!-- Contact Button -->
        <v-btn prepend-icon="mdi-card-account-mail" class="contact" to="/contact">Contact</v-btn>

        <!-- Movies Edit Menu (admin only) -->
        <v-menu open-on-hover offset-y transition="scale-transition" v-if="userdefine === 1" max-width="200">
          <template #activator="{ props }">
            <v-btn prepend-icon="mdi-movie-edit" class="movie" v-bind="props">Movies edit</v-btn>
          </template>
          <v-list>
            <v-list-subheader class="text-h5">Categories</v-list-subheader>
            <v-list-item :to="{ path: '/movies/lists' }" link>
              <v-list-item-title class="list">Movie Lists</v-list-item-title>
            </v-list-item>
            <v-list-item :to="{ path: '/movie/add' }" link>
              <v-list-item-title class="list">Movie Add</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>

        <!-- User List Button (admin only) -->
        <v-btn prepend-icon="mdi-account-multiple" class="userlist" to="/user/lists" v-if="userdefine === 1">User List</v-btn>

        <!-- Login / Logout Button -->
        <v-btn class="sign-in-btn" text @click="loginAction">
          <v-icon class="mr-1">mdi-account-key-outline</v-icon>
          <span class="login-text">{{ !$store.getters.Get_Login_State ? 'Sign In' : 'Sign out' }}</span>
        </v-btn>

        <!-- Profile Menu -->
        <v-menu offset-y :close-on-content-click="false">
          <template #activator="{ props }">
            <v-btn class="profile-btn" elevation="0" rounded v-bind="props" >
              <v-avatar>
                <img :src="previewImage || profileImage" alt="avatar" />
              </v-avatar>
            </v-btn>
          </template>
          <v-card width="360" class="pa-3" style="background-color:#373737;">
            <v-card width="300" height="200" class="pa-4 mx-auto" style="background-color: #5a5a5a;">
              <v-row align="center" justify="center" class="mb-4">
                <v-avatar size="80" style="margin-top: 10px;">
                  <img :src="profileImage" alt="avatar" />
                </v-avatar>
              </v-row>
              <v-row justify="center">
                <div class="text-subtitle-1 font-weight-bold">
                  {{ $store.state.user?.name || 'nyi nyi lwin' }}
                </div>
              </v-row>
              <v-row justify="center">
                <div class="text-caption text-grey">
                  {{ $store.state.user?.email || 'No email available' }}
                </div>
              </v-row>
            </v-card>

            <v-row class="itenrow1" align="center" style="cursor:pointer;">
              <v-icon class="mr-1" size="20">mdi-key-variant</v-icon>
              <a href="#" class="link" @click.prevent> Password change </a>
            </v-row>

            <v-row class="itenrow" align="center" style="cursor:pointer;" @click.prevent="triggerFilePicker">
              <v-icon class="mr-1" size="20">mdi-grease-pencil</v-icon>
              <span class="link">Customize profile</span>
            </v-row>

            <!-- Hidden File Input -->
            <input
              ref="fileInput"
              type="file"
              accept="image/*"
              style="display: none"
              @change="handleImageUpload"
            />
          </v-card>
        </v-menu>

        <!-- Notification Button -->
        <v-btn prepend-icon="mdi-bell" class="noti"></v-btn>
      </v-container>
    </v-app-bar>

    <!-- Fixed Dropdown for Search Results -->
<v-card
  v-if="showResults && search"
  class="fixed-search-dropdown"
  elevation="6"
  color="transparent"
>
  <v-list>
    <v-list-item
      v-for="item in filteredCrimeTitles"
      :key="item.id"
      :to="`/movie/${item.id}`"
      link
    >
      <v-row no-gutters>
        <v-list-item-avatar>
          <v-img
            :src="fixImagePath(item.movie_poster)"
            cover
            width="60"
            height="90"
            :alt="item.name"
          />
        </v-list-item-avatar>

        <v-list-item-content class="pl-2 pt-3">
          <v-list-item-title>{{ item.name }}</v-list-item-title>
          <v-list-item-subtitle>
            {{ item.type }} • {{ formatDate(item.movie_created_date) }}
          </v-list-item-subtitle>
        </v-list-item-content>
      </v-row>
    </v-list-item>

    <v-list-item v-if="filteredCrimeTitles.length === 0">
      <v-list-item-title>No results found.</v-list-item-title>
    </v-list-item>
  </v-list>
</v-card>


    <!-- Main content -->
    <v-main>
      <router-view />
    </v-main>

    <!-- Footer -->
    <transition name="fade">
      <v-footer
        v-if="showFooter"
        app
        class="footer d-flex align-center justify-center"
        style="width: 100%; height: 60px"
      >
        <p class="footer-text">© 2023 Co-Movie. All rights reserved.</p>
      </v-footer>
    </transition>
  </v-app>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import profilePic from '@/assets/profile.jpg'
import api from '@/utils/api.js'
import { get_AllMovies } from '@/utils/api.js'

const BASE_URL = 'http://localhost:8082/storage'

const router = useRouter()
const store = useStore()
const previewImage = ref(null)
const search = ref('')
const showResults = ref(false)
const showFooter = ref(false)
const titles = ref([])
const fileInput = ref(null)
const login = JSON.parse(localStorage.getItem("user"))

const userRole = computed(() => store.getters.GET_USERROLE)
const userinfo = computed(() => store.getters.GET_USER_INFO)

const profileImage = computed(() => {
  if (previewImage.value) return previewImage.value
  return userinfo.value?.image ? `${BASE_URL}${userinfo.value.image}` : profilePic
})

const userdefine = computed(() => userRole.value === 'admin' ? 1 : 2)
const appBarClass = computed(() => {
  switch (userRole.value) {
    case 'admin': return 'navbar-admin'
    case 'user': return 'navbar-user'
    default: return 'navbar-user'
  }
})
console.log("User Role in app vue:", login?.role)

watch(userinfo, (newVal) => {
  if (newVal && newVal.userId) {
    console.log("User Info Changed:", newVal)
    image(newVal.userId)
  }
}, { immediate: true })

watch(userRole, (newVal) => {
  console.log('User Role:', newVal)
})

const fixImagePath = (path) => {
  if (!path) return ''
  return `http://localhost:8082/storage${path}`
}

const formatDate = (timestamp) => {
  if (!timestamp) return ''
  const date = new Date(Number(timestamp))
  return date.toISOString().split('T')[0]
}

onMounted(async () => {
  await fetchUserFromServer()
  try {
    const res = await get_AllMovies('/getAll')
    const data = await res.json()
    titles.value = data
  } catch (err) {
    console.error('Failed to load movies', err)
  }
  window.addEventListener('scroll', handleScroll)
})

onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll)
})

const filteredCrimeTitles = computed(() =>
  titles.value.filter(item =>
    item.name?.toLowerCase().includes(search.value.toLowerCase())
  )
)

const hideResults = () => {
  setTimeout(() => {
    showResults.value = false
  }, 200)
}

const triggerFilePicker = () => {
  fileInput.value?.click()
}

async function image(id) {
  try {
    const res = await api.getImageWithId(`/user/${id}/image`)
    const data = await res.json()
    if (data.image) {
      previewImage.value = null
    } else {
      previewImage.value = profilePic
    }
  } catch (err) {
    console.error('Failed to load user image:', err)
    previewImage.value = profilePic
  }
}

async function fetchUserFromServer() {
  try {
    const response = await api.get('/current-user')
    if (response.ok) {
      const data = await response.json()
      console.log("Fetched user from server:", data)
      store.commit("SET_USER", data)
      store.commit("SET_USER_ROLE", data.role)
    } else {
      console.warn("User not logged in or session expired.")
    }
  } catch (error) {
    console.error("Failed to fetch user from server:", error)
  }
}

const handleImageUpload = async (event) => {
  const file = event.target.files[0]
  if (!file) return
  previewImage.value = URL.createObjectURL(file)
  const formData = new FormData()
  formData.append('image', file)
  try {
    const response = await api.imageUpload(`/${userinfo.value.userId}/image-upload`, formData)
    const data = await response.json()
    if (response.ok) {
      console.log('Image uploaded successfully:', data)
      await image(userinfo.value.userId)
    } else {
      console.error('Image upload failed:', data.message)
    }
  } catch (err) {
    console.error('Upload error:', err)
  }
}

const loginAction = () => {
  if (store.getters.Get_Login_State) {
    store.dispatch("LogOutStateChange")
    router.push("/signin")
    localStorage.clear()
  } else {
    router.push("/signin")
  }
}

const goToCategory = (category) => {
  store.dispatch('addToCategory', category)
  router.push('/movies')
}

const handleScroll = () => {
  const scrollTop = window.scrollY
  const windowHeight = window.innerHeight
  const fullHeight = document.documentElement.scrollHeight
  showFooter.value = scrollTop + windowHeight >= fullHeight - 5
}
</script>

<style scoped>
.fixed-search-dropdown {
  position: fixed;
  top: 70px;
  left: 50%;
  transform: translateX(-50%);
  width: 400px;
  max-height: 400px;
  overflow-y: auto;
  border-radius: 8px;
  z-index: 999;
  background-color: #121212;
  color: white;
}

.footer-text {
  font-size: 14px;
  color: #aaa;
  margin: 0;
}

.v-footer,
.v-app-bar {
  background-color: #121212;
}

.custom-navbar {
  background: linear-gradient(90deg, #121212, #1f1f1f);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.6);
  padding: 0 24px;
  height: 64px;
  display: flex;
  align-items: center;
}

.logo {
  font-size: 24px;
  font-weight: bold;
  letter-spacing: 1px;
  color: white;
}

.logo-primary {
  color: #ff3d00;
}

.logo-secondary {
  color: white;
}

.search-box {
  width: 350px;
  height: 40px;
  background-color: #1e1e1e;
  border-radius: 20px;
  font-size: 16px;
  color: white;
  border: 1px solid #333;
  transition: border 0.3s ease;
  padding: 0 12px;
  margin-left: 10px;
}

.sign-in-btn {
  background-color: #ff3d00;
  color: white;
  font-weight: bold;
  transition: background 0.3s ease;
  margin-left: 10px;
}
.sign-in-btn:hover {
  background-color: #4e2012;
}

.userlist,
.home,
.contact,
.movie,
.molist,
.noti {
  color: white;
  font-weight: bold;
  border-radius: 20px;
  margin-left: 5px;
}

.userlist:hover,
.molist:hover,
.home:hover,
.contact:hover,
.movie:hover {
  background-color: #ffffff;
  color: #121212;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.v-list-item {
  min-width: 200px;
}

.v-list-item-title {
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
}
.list:hover {
  color: #ff3d00;
  transition: color 0.3s ease;
}

.profile-btn {
  background-color: transparent;
  color: white;
  border: none;
  padding: 0;
  min-width: unset;
  margin-left: 10px;
}

.profile-btn .v-avatar {
  width: 40px;
  height: 40px;
}

.profile-btn img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}

.link {
  color: #ffffff;
  text-decoration: none;
  padding-left: 20px;
}

.itenrow1:hover,
.itenrow:hover {
  background-color: #656565;
  cursor: pointer;
}

.itenrow1 {
  margin-top: 20px;
  padding: 3px;
  display: flex;
  align-items: center;
}

.itenrow {
  padding: 3px;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
}

/* nav styles */
.navbar-admin {
  background: linear-gradient(90deg, #2e003e, #5a005f);
  box-shadow: 0 4px 12px rgba(255, 0, 255, 0.3);
}

.navbar-user {
  background: linear-gradient(90deg, #121212, #1f1f1f);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.6);
}

/* Fade transition */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
